import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/rendering.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = WisamStore();
  await store.load();
  runApp(WisamApp(store: store));
}

const gold = Color(0xFFC9A227);
const goldSoft = Color(0xFFE9D89A);
const emerald = Color(0xFF0E7C5B);
const paper = Color(0xFFFFFDF6);
const ink = Color(0xFF1B1611);

String uid() => '${DateTime.now().microsecondsSinceEpoch}-${math.Random().nextInt(999999)}';

String arDigits(Object value) {
  const digits = '٠١٢٣٤٥٦٧٨٩';
  return value.toString().replaceAllMapped(RegExp(r'\d'), (m) => digits[int.parse(m.group(0)!)]);
}

String dateKey(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
String todayKey() => dateKey(DateTime.now());

String fullDate(DateTime d) {
  const weekdays = ['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'];
  const months = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
  return '${weekdays[d.weekday - 1]}، ${arDigits(d.day)} ${months[d.month - 1]} ${arDigits(d.year)}';
}

String shortDate(DateTime d) => '${arDigits(d.day)}/${arDigits(d.month)}/${arDigits(d.year)}';

String timeAgo(int ms) {
  final diff = DateTime.now().millisecondsSinceEpoch - ms;
  final m = diff ~/ 60000;
  if (m < 1) return 'الآن';
  if (m < 60) return 'قبل ${arDigits(m)} دقيقة';
  final h = m ~/ 60;
  if (h < 24) return 'قبل ${arDigits(h)} ساعة';
  final d = h ~/ 24;
  if (d < 7) return 'قبل ${arDigits(d)} يوم';
  return shortDate(DateTime.fromMillisecondsSinceEpoch(ms));
}

String greeting() {
  final h = DateTime.now().hour;
  if (h < 5) return 'ليلة سعيدة';
  if (h < 12) return 'صباحُ الإبداع';
  if (h < 17) return 'نهارُك نور';
  return 'مساءُ الخير';
}

int wordsCount(String text) {
  final s = text.trim();
  return s.isEmpty ? 0 : s.split(RegExp(r'\s+')).length;
}

class NoteModel {
  String id, title, content, color;
  String? folderId, drawing;
  bool pinned;
  int createdAt, updatedAt;
  NoteModel({
    required this.id, this.title = '', this.content = '', this.color = 'paper',
    this.folderId, this.drawing, this.pinned = false, required this.createdAt, required this.updatedAt,
  });
  Map<String,dynamic> toJson() => {'id':id,'title':title,'content':content,'color':color,'folderId':folderId,'drawing':drawing,'pinned':pinned,'createdAt':createdAt,'updatedAt':updatedAt};
  factory NoteModel.fromJson(Map<String,dynamic> j) => NoteModel(
    id: '${j['id'] ?? uid()}', title: '${j['title'] ?? ''}', content: '${j['content'] ?? ''}',
    color: '${j['color'] ?? 'paper'}', folderId: j['folderId'] as String?, drawing: j['drawing'] as String?,
    pinned: j['pinned'] == true, createdAt: (j['createdAt'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch,
    updatedAt: (j['updatedAt'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch,
  );
}

class FolderModel {
  String id,name,color;
  FolderModel({required this.id,required this.name,required this.color});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'color':color};
  factory FolderModel.fromJson(Map<String,dynamic> j)=>FolderModel(id:'${j['id']}',name:'${j['name']??''}',color:'${j['color']??'#C9A227'}');
}

class TaskModel {
  String id,text,priority;
  bool done;
  int createdAt;
  TaskModel({required this.id,required this.text,this.priority='low',this.done=false,required this.createdAt});
  Map<String,dynamic> toJson()=>{'id':id,'text':text,'priority':priority,'done':done,'createdAt':createdAt};
  factory TaskModel.fromJson(Map<String,dynamic> j)=>TaskModel(id:'${j['id']}',text:'${j['text']??''}',priority:'${j['priority']??'low'}',done:j['done']==true,createdAt:(j['createdAt'] as num?)?.toInt()??DateTime.now().millisecondsSinceEpoch);
}

class ListItemModel {
  String id,name,unit;
  double qty,have;
  bool done;
  ListItemModel({required this.id,required this.name,this.qty=1,this.unit='قطعة',this.done=false,this.have=0});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'qty':qty,'unit':unit,'done':done,'have':have};
  factory ListItemModel.fromJson(Map<String,dynamic> j)=>ListItemModel(id:'${j['id']}',name:'${j['name']??''}',qty:(j['qty'] as num?)?.toDouble()??1,unit:'${j['unit']??'قطعة'}',done:j['done']==true,have:(j['have'] as num?)?.toDouble()??0);
}

class QuantityList {
  String id,name,color;
  int createdAt;
  List<ListItemModel> items;
  QuantityList({required this.id,required this.name,required this.color,required this.createdAt,required this.items});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'color':color,'createdAt':createdAt,'items':items.map((e)=>e.toJson()).toList()};
  factory QuantityList.fromJson(Map<String,dynamic> j)=>QuantityList(id:'${j['id']}',name:'${j['name']??''}',color:'${j['color']??'#C9A227'}',createdAt:(j['createdAt'] as num?)?.toInt()??0,items:((j['items'] as List?)??[]).map((e)=>ListItemModel.fromJson(Map<String,dynamic>.from(e))).toList());
}

class Chapter {
  String id,title,content;
  Chapter({required this.id,this.title='',this.content=''});
  Map<String,dynamic> toJson()=>{'id':id,'title':title,'content':content};
  factory Chapter.fromJson(Map<String,dynamic> j)=>Chapter(id:'${j['id']}',title:'${j['title']??''}',content:'${j['content']??''}');
}

class BookModel {
  String id,title,author,palette,pattern,coverFont,textFont,conclusion;
  int createdAt,updatedAt;
  List<Chapter> chapters;
  BookModel({required this.id,this.title='',this.author='',this.palette='emerald',this.pattern='geo',this.coverFont='Amiri',this.textFont='Cairo',this.conclusion='',required this.createdAt,required this.updatedAt,required this.chapters});
  Map<String,dynamic> toJson()=>{'id':id,'title':title,'author':author,'palette':palette,'pattern':pattern,'coverFont':coverFont,'textFont':textFont,'conclusion':conclusion,'createdAt':createdAt,'updatedAt':updatedAt,'chapters':chapters.map((e)=>e.toJson()).toList()};
  factory BookModel.fromJson(Map<String,dynamic> j)=>BookModel(id:'${j['id']}',title:'${j['title']??''}',author:'${j['author']??''}',palette:'${j['palette']??'emerald'}',pattern:'${j['pattern']??'geo'}',coverFont:'${j['coverFont']??'Amiri'}',textFont:'${j['textFont']??'Cairo'}',conclusion:'${j['conclusion']??''}',createdAt:(j['createdAt'] as num?)?.toInt()??0,updatedAt:(j['updatedAt'] as num?)?.toInt()??0,chapters:((j['chapters'] as List?)??[]).map((e)=>Chapter.fromJson(Map<String,dynamic>.from(e))).toList());
}

class WisamStore extends ChangeNotifier {
  final notes=<NoteModel>[], folders=<FolderModel>[], lists=<QuantityList>[], books=<BookModel>[];
  final tasks=<String,List<TaskModel>>{};
  bool dark=false, ready=false;
  static const key='wisam_flutter_db_v2', themeKey='wisam_flutter_theme';

  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    dark=p.getBool(themeKey)??false;
    final raw=p.getString(key);
    if(raw!=null) {
      try {
        final j=Map<String,dynamic>.from(jsonDecode(raw));
        notes.addAll(((j['notes'] as List?)??[]).map((e)=>NoteModel.fromJson(Map<String,dynamic>.from(e))));
        folders.addAll(((j['folders'] as List?)??[]).map((e)=>FolderModel.fromJson(Map<String,dynamic>.from(e))));
        lists.addAll(((j['lists'] as List?)??[]).map((e)=>QuantityList.fromJson(Map<String,dynamic>.from(e))));
        books.addAll(((j['books'] as List?)??[]).map((e)=>BookModel.fromJson(Map<String,dynamic>.from(e))));
        final tj=Map<String,dynamic>.from(j['tasks']??{});
        tj.forEach((k,v)=>tasks[k]=((v as List?)??[]).map((e)=>TaskModel.fromJson(Map<String,dynamic>.from(e))).toList());
      } catch (_) { seed(); }
    } else { seed(); }
    ready=true; notifyListeners();
  }
  void seed() {
    if(notes.isEmpty) {
      final now=DateTime.now().millisecondsSinceEpoch;
      notes.add(NoteModel(id:uid(),title:'أهلًا بك في وِسام',content:'هذه ملاحظتك الأولى. اكتب أفكارك هنا واحفظها محليًا على جهازك.',pinned:true,createdAt:now,updatedAt:now));
    }
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setBool(themeKey,dark);
    await p.setString(key,jsonEncode({
      'app':'wisam','version':2,'exportedAt':DateTime.now().toIso8601String(),
      'notes':notes.map((e)=>e.toJson()).toList(),'folders':folders.map((e)=>e.toJson()).toList(),
      'lists':lists.map((e)=>e.toJson()).toList(),'books':books.map((e)=>e.toJson()).toList(),
      'tasks':tasks.map((k,v)=>MapEntry(k,v.map((e)=>e.toJson()).toList()))
    }));
  }
  void changed(){notifyListeners(); save();}
  void toggleTheme(){dark=!dark; changed();}
  void addNote({String title='',String content='',String color='paper',String? folderId}){final n=DateTime.now().millisecondsSinceEpoch;notes.insert(0,NoteModel(id:uid(),title:title,content:content,color:color,folderId:folderId,createdAt:n,updatedAt:n));changed();}
  void updateNote(NoteModel n,{String? title,String? content,bool? pinned,String? folderId,String? color}){n.title=title??n.title;n.content=content??n.content;n.pinned=pinned??n.pinned;n.folderId=folderId??n.folderId;n.color=color??n.color;n.updatedAt=DateTime.now().millisecondsSinceEpoch;changed();}
  void deleteNote(String id){notes.removeWhere((n)=>n.id==id);changed();}
  void addFolder(String name,String color){folders.add(FolderModel(id:uid(),name:name,color:color));changed();}
  void deleteFolder(String id){folders.removeWhere((f)=>f.id==id);for(final n in notes){if(n.folderId==id)n.folderId=null;}changed();}
  void addTask(String day,String text,String priority){tasks.putIfAbsent(day,()=>[]).add(TaskModel(id:uid(),text:text,priority:priority,createdAt:DateTime.now().millisecondsSinceEpoch));changed();}
  void toggleTask(String day,String id){final x=tasks[day]??[];final t=x.firstWhere((e)=>e.id==id);t.done=!t.done;changed();}
  void deleteTask(String day,String id){tasks[day]?.removeWhere((e)=>e.id==id);changed();}
  void moveUnfinished(String from,String to){final src=tasks[from]??[];final moved=src.where((e)=>!e.done).toList();src.removeWhere((e)=>!e.done);tasks.putIfAbsent(to,()=>[]).addAll(moved);changed();}
  void addList(String name,String color){lists.add(QuantityList(id:uid(),name:name,color:color,createdAt:DateTime.now().millisecondsSinceEpoch,items:[]));changed();}
  void deleteList(String id){lists.removeWhere((l)=>l.id==id);changed();}
  void addItem(QuantityList l,String name,double qty,String unit){l.items.add(ListItemModel(id:uid(),name:name,qty:qty,unit:unit));changed();}
  void deleteItem(QuantityList l,String id){l.items.removeWhere((i)=>i.id==id);changed();}
  void updateItem(QuantityList l,ListItemModel i,{double? have,bool? done,String? name,double? qty,String? unit}){i.have=have??i.have;i.done=done??i.done;i.name=name??i.name;i.qty=qty??i.qty;i.unit=unit??i.unit;changed();}
  void addBook(){final n=DateTime.now().millisecondsSinceEpoch;books.insert(0,BookModel(id:uid(),title:'كتاب جديد',author:'',createdAt:n,updatedAt:n,chapters:[Chapter(id:uid(),title:'الفصل الأول')]));changed();}
  void deleteBook(String id){books.removeWhere((b)=>b.id==id);changed();}
  void updateBook(BookModel b){b.updatedAt=DateTime.now().millisecondsSinceEpoch;changed();}
  String exportJson()=>jsonEncode({'app':'wisam','version':2,'exportedAt':DateTime.now().toIso8601String(),'notes':notes.map((e)=>e.toJson()).toList(),'folders':folders.map((e)=>e.toJson()).toList(),'lists':lists.map((e)=>e.toJson()).toList(),'books':books.map((e)=>e.toJson()).toList(),'tasks':tasks.map((k,v)=>MapEntry(k,v.map((e)=>e.toJson()).toList()))});
  Future<bool> importJson(String text) async {
    try {
      final j=Map<String,dynamic>.from(jsonDecode(text));
      notes..clear()..addAll(((j['notes'] as List?)??[]).map((e)=>NoteModel.fromJson(Map<String,dynamic>.from(e))));
      folders..clear()..addAll(((j['folders'] as List?)??[]).map((e)=>FolderModel.fromJson(Map<String,dynamic>.from(e))));
      lists..clear()..addAll(((j['lists'] as List?)??[]).map((e)=>QuantityList.fromJson(Map<String,dynamic>.from(e))));
      books..clear()..addAll(((j['books'] as List?)??[]).map((e)=>BookModel.fromJson(Map<String,dynamic>.from(e))));
      tasks.clear(); final tj=Map<String,dynamic>.from(j['tasks']??{});tj.forEach((k,v)=>tasks[k]=((v as List?)??[]).map((e)=>TaskModel.fromJson(Map<String,dynamic>.from(e))).toList());
      changed(); return true;
    } catch (_) { return false; }
  }
  Future<void> reset(){notes.clear();folders.clear();lists.clear();books.clear();tasks.clear();seed();changed();return Future.value();}
  int get wordTotal => notes.fold<int>(0,(a,n)=>a+wordsCount(n.content))+books.fold<int>(0,(a,b)=>a+b.chapters.fold<int>(0,(x,c)=>x+wordsCount(c.content))+wordsCount(b.conclusion));
  int get noteCount=>notes.length;
  int get taskCount=>tasks.values.fold(0,(a,v)=>a+v.length);
}

class WisamApp extends StatelessWidget {
  final WisamStore store;
  const WisamApp({super.key,required this.store});
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:store,builder:(context,_){
    return MaterialApp(debugShowCheckedModeBanner:false,title:'وِسام',theme:buildTheme(false),darkTheme:buildTheme(true),themeMode:store.dark?ThemeMode.dark:ThemeMode.light,home:Directionality(textDirection:TextDirection.rtl,child:InheritedWisam(store:store,child:HomeShell(store:store))));
  });
}

ThemeData buildTheme(bool dark){
  final scheme=ColorScheme.fromSeed(seedColor:emerald,brightness:dark?Brightness.dark:Brightness.light);
  return ThemeData(useMaterial3:true,colorScheme:scheme,scaffoldBackgroundColor:dark?const Color(0xFF17120C):const Color(0xFFF7F2E8),fontFamily:'sans',inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:dark?const Color(0xFF211B14):paper,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none)));
}

enum ViewPage {home,notes,tasks,lists,draw,books}

class HomeShell extends StatefulWidget {
  final WisamStore store;
  const HomeShell({super.key,required this.store});
  @override State<HomeShell> createState()=>_HomeShellState();
}
class _HomeShellState extends State<HomeShell>{
  ViewPage page=ViewPage.home;
  String? folderFilter;
  int navIndex=0;
  @override Widget build(BuildContext context){
    final wide=MediaQuery.sizeOf(context).width>=900;
    return Scaffold(
      drawer:wide?null:Drawer(child:Sidebar(store:widget.store,page:page,onPage:(p){setState(()=>page=p);Navigator.pop(context);},folderFilter:folderFilter,onFolder:(f){setState((){folderFilter=f;page=ViewPage.notes;});Navigator.pop(context);},)),
      body:SafeArea(child:Row(children:[
        if(wide) SizedBox(width:270,child:Sidebar(store:widget.store,page:page,onPage:(p)=>setState(()=>page=p),folderFilter:folderFilter,onFolder:(f){setState((){folderFilter=f;page=ViewPage.notes;});})),
        Expanded(child:PageBody(store:widget.store,page:page,folderFilter:folderFilter,onPage:(p)=>setState(()=>page=p)))
      ])),
      bottomNavigationBar:wide?null:NavigationBar(selectedIndex:navIndex,onDestinationSelected:(i){final p=[ViewPage.home,ViewPage.notes,ViewPage.tasks,ViewPage.lists,ViewPage.books][i];setState((){navIndex=i;page=p;});},destinations:const [
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'الرئيسية'),
        NavigationDestination(icon:Icon(Icons.note_outlined),selectedIcon:Icon(Icons.note),label:'الملاحظات'),
        NavigationDestination(icon:Icon(Icons.check_circle_outline),selectedIcon:Icon(Icons.check_circle),label:'المهام'),
        NavigationDestination(icon:Icon(Icons.shopping_basket_outlined),selectedIcon:Icon(Icons.shopping_basket),label:'القوائم'),
        NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'الكتب'),
      ]),
    );
  }
}

class Sidebar extends StatelessWidget {
  final WisamStore store; final ViewPage page; final ValueChanged<ViewPage> onPage; final String? folderFilter; final ValueChanged<String?> onFolder;
  const Sidebar({super.key,required this.store,required this.page,required this.onPage,required this.folderFilter,required this.onFolder});
  @override Widget build(BuildContext context){
    final nav=[(ViewPage.home,'الرئيسية',Icons.home_outlined),(ViewPage.notes,'الملاحظات',Icons.sticky_note_2_outlined),(ViewPage.tasks,'مهام اليوم',Icons.checklist),(ViewPage.lists,'القوائم والكميات',Icons.shopping_basket_outlined),(ViewPage.draw,'المرسم',Icons.draw_outlined),(ViewPage.books,'المكتبة',Icons.menu_book_outlined)];
    return Material(color:const Color(0xFF17120C),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const SizedBox(height:22),const ListTile(leading:CircleAvatar(backgroundColor:gold,child:Icon(Icons.edit,color:Color(0xFF17120C))),title:Text('وِسام',style:TextStyle(color:goldSoft,fontSize:27,fontWeight:FontWeight.w800)),subtitle:Text('أهلًا بك في رحلة الإبداع',style:TextStyle(color:Color(0xFFA89A7D),fontSize:11))),
      const SizedBox(height:8),
      ...nav.map((x)=>Padding(padding:const EdgeInsets.symmetric(horizontal:10,vertical:2),child:ListTile(dense:true,selected:page==x.$1,selectedTileColor:gold,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16)),iconColor:page==x.$1?ink:goldSoft,textColor:page==x.$1?ink:const Color(0xFFEFE7D5),leading:Icon(x.$3),title:Text(x.$2),onTap:()=>onPage(x.$1)))),
      const Padding(padding:EdgeInsets.all(16),child:Text('المجلدات',style:TextStyle(color:Color(0xFF8D8168),fontWeight:FontWeight.bold))),
      Expanded(child:ListView(children:[
        ListTile(dense:true,selected:folderFilter==null&&page==ViewPage.notes,leading:const Icon(Icons.folder_outlined,color:Color(0xFF8D8168)),title:const Text('جميع الملاحظات',style:TextStyle(color:Color(0xFFEFE7D5))),trailing:Text(arDigits(store.notes.length),style:const TextStyle(color:Color(0xFF8D8168))),onTap:()=>onFolder(null)),
        ...store.folders.map((f)=>ListTile(dense:true,selected:folderFilter==f.id,leading:CircleAvatar(radius:5,backgroundColor:parseColor(f.color)),title:Text(f.name,style:const TextStyle(color:Color(0xFFEFE7D5))),trailing:Text(arDigits(store.notes.where((n)=>n.folderId==f.id).length),style:const TextStyle(color:Color(0xFF8D8168))),onTap:()=>onFolder(f.id))),
      ])),
      Padding(padding:const EdgeInsets.all(12),child:Column(children:[
        Text('${arDigits(store.wordTotal)} كلمة محفوظة على جهازك',style:const TextStyle(color:Color(0xFF8D8168),fontSize:11)),
        Row(children:[
          Expanded(child:IconButton(onPressed:()=>backup(context),icon:const Icon(Icons.download,color:goldSoft),tooltip:'نسخة احتياطية')),
          Expanded(child:IconButton(onPressed:()=>importBackup(context),icon:const Icon(Icons.upload,color:goldSoft),tooltip:'استيراد')),
          Expanded(child:IconButton(onPressed:store.toggleTheme,icon:Icon(store.dark?Icons.light_mode:Icons.dark_mode,color:goldSoft))),
          Expanded(child:IconButton(onPressed:()=>settingsDialog(context,store),icon:const Icon(Icons.settings,color:goldSoft))),
        ])
      ]))
    ]));
  }
}

class PageBody extends StatelessWidget{
  final WisamStore store; final ViewPage page; final String? folderFilter; final ValueChanged<ViewPage> onPage;
  const PageBody({super.key,required this.store,required this.page,required this.folderFilter,required this.onPage});
  @override Widget build(BuildContext context)=>switch(page){
    ViewPage.home=>HomePage(store:store,onPage:onPage),
    ViewPage.notes=>NotesPage(store:store,folderId:folderFilter),
    ViewPage.tasks=>TasksPage(store:store),
    ViewPage.lists=>ListsPage(store:store),
    ViewPage.draw=>DrawPage(store:store),
    ViewPage.books=>BooksPage(store:store),
  };
}

class HomePage extends StatelessWidget{
  final WisamStore store; final ValueChanged<ViewPage> onPage;
  const HomePage({super.key,required this.store,required this.onPage});
  @override Widget build(BuildContext context){
    final wisdoms=['خير الكلام ما قلّ ودلّ.','الصبر مفتاح الفرج.','الجار قبل الدار.','قليل دائم خير من كثير منقطع.','اليد الواحدة لا تصفق.'];
    final w=wisdoms[DateTime.now().day%wisdoms.length];
    return AppScroll(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Header(title:greeting(),subtitle:fullDate(DateTime.now())),
      Card(child:Padding(padding:const EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('حكمة اليوم',style:TextStyle(color:emerald,fontWeight:FontWeight.bold)),const SizedBox(height:12),Text('“$w”',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w700)),const SizedBox(height:8),const Text('حكمة عربية',style:TextStyle(color:Colors.grey))]))),
      const SizedBox(height:14),
      Wrap(spacing:12,runSpacing:12,children:[
        StatCard(label:'الملاحظات',value:store.noteCount.toString(),icon:Icons.note_alt_outlined,onTap:()=>onPage(ViewPage.notes)),
        StatCard(label:'المهام',value:store.taskCount.toString(),icon:Icons.checklist,onTap:()=>onPage(ViewPage.tasks)),
        StatCard(label:'القوائم',value:store.lists.length.toString(),icon:Icons.shopping_basket_outlined,onTap:()=>onPage(ViewPage.lists)),
        StatCard(label:'الكتب',value:store.books.length.toString(),icon:Icons.menu_book,onTap:()=>onPage(ViewPage.books)),
      ]),
      const SizedBox(height:14),
      SectionCard(title:'آخر الملاحظات',icon:Icons.sticky_note_2_outlined,child:store.notes.isEmpty?const Text('لا توجد ملاحظات'):Column(children:store.notes.take(4).map((n)=>ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(backgroundColor:goldSoft,child:Icon(Icons.note,color:ink)),title:Text(n.title.isEmpty?'بلا عنوان':n.title),subtitle:Text(timeAgo(n.updatedAt)),onTap:()=>onPage(ViewPage.notes))).toList()))
    ]));
  }
}

class NotesPage extends StatefulWidget{final WisamStore store;final String? folderId;const NotesPage({super.key,required this.store,this.folderId});@override State<NotesPage> createState()=>_NotesPageState();}
class _NotesPageState extends State<NotesPage>{
  String query='';
  @override Widget build(BuildContext context){
    final ns=widget.store.notes.where((n)=>(widget.folderId==null||n.folderId==widget.folderId)&&(query.isEmpty||n.title.contains(query)||n.content.contains(query))).toList()..sort((a,b){if(a.pinned!=b.pinned)return a.pinned?-1:1;return b.updatedAt.compareTo(a.updatedAt);});
    return AppScroll(child:Column(children:[
      Header(title:'الملاحظات',subtitle:'${arDigits(ns.length)} ملاحظة',actions:[IconButton(onPressed:()=>editNote(context,widget.store),icon:const Icon(Icons.add_circle_outline))]),
      TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'ابحث في الملاحظات'),onChanged:(v)=>setState(()=>query=v)),
      const SizedBox(height:12),
      if(ns.isEmpty) const EmptyState(text:'لا توجد ملاحظات'),
      ...ns.map((n)=>NoteCard(note:n,onTap:()=>editNote(context,widget.store,n),onDelete:(){widget.store.deleteNote(n.id);},onTogglePin:(){widget.store.updateNote(n,pinned:!n.pinned);}))
    ]));
  }
}

class NoteCard extends StatelessWidget{final NoteModel note;final VoidCallback onTap,onDelete,onTogglePin;const NoteCard({super.key,required this.note,required this.onTap,required this.onDelete,required this.onTogglePin});
@override Widget build(BuildContext context)=>Card(child:ListTile(onTap:onTap,leading:CircleAvatar(backgroundColor:noteColor(note.color),child:Icon(note.drawing!=null?Icons.brush:Icons.note,color:ink)),title:Row(children:[Expanded(child:Text(note.title.isEmpty?'بلا عنوان':note.title,style:const TextStyle(fontWeight:FontWeight.bold))),if(note.pinned)const Icon(Icons.push_pin,size:16,color:gold)]),subtitle:Text(note.content.isEmpty?'بدون محتوى':note.content,maxLines:2,overflow:TextOverflow.ellipsis),trailing:PopupMenuButton<String>(onSelected:(v){if(v=='delete')onDelete();if(v=='pin')onTogglePin();},itemBuilder:(_)=>const [PopupMenuItem(value:'pin',child:Text('تثبيت/إلغاء التثبيت')),PopupMenuItem(value:'delete',child:Text('حذف'))])));
}

Future<void> editNote(BuildContext context,WisamStore store,[NoteModel? existing]) async {
  final title=TextEditingController(text:existing?.title??'');
  final content=TextEditingController(text:existing?.content??'');
  final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:Text(existing==null?'ملاحظة جديدة':'تعديل الملاحظة'),content:SizedBox(width:520,child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(hintText:'العنوان')),const SizedBox(height:10),TextField(controller:content,minLines:6,maxLines:12,decoration:const InputDecoration(hintText:'اكتب ملاحظتك هنا...'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حفظ'))]));
  if(ok==true){if(existing==null)store.addNote(title:title.text.trim(),content:content.text);else store.updateNote(existing,title:title.text.trim(),content:content.text);}
}

class TasksPage extends StatefulWidget{final WisamStore store;const TasksPage({super.key,required this.store});@override State<TasksPage> createState()=>_TasksPageState();}
class _TasksPageState extends State<TasksPage>{
  DateTime day=DateTime.now();
  @override Widget build(BuildContext context){final key=dateKey(day);final ts=widget.store.tasks[key]??[];
    return AppScroll(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Header(title:'مهام اليوم',subtitle:fullDate(day),actions:[IconButton(onPressed:()=>setState(()=>day=day.subtract(const Duration(days:1))),icon:const Icon(Icons.chevron_right)),IconButton(onPressed:()=>setState(()=>day=DateTime.now()),icon:const Icon(Icons.today)),IconButton(onPressed:()=>setState(()=>day=day.add(const Duration(days:1))),icon:const Icon(Icons.chevron_left))]),
      FilledButton.icon(onPressed:()=>addTaskDialog(context,widget.store,key),icon:const Icon(Icons.add),label:const Text('إضافة مهمة')),
      const SizedBox(height:12),
      if(ts.isEmpty)const EmptyState(text:'لا توجد مهام لهذا اليوم'),
      ...ts.map((t)=>Card(child:CheckboxListTile(value:t.done,onChanged:(_)=>widget.store.toggleTask(key,t.id),title:Text(t.text,style:TextStyle(decoration:t.done?TextDecoration.lineThrough:null)),subtitle:Text(t.priority=='high'?'أولوية عالية':'أولوية منخفضة'),secondary:IconButton(onPressed:()=>widget.store.deleteTask(key,t.id),icon:const Icon(Icons.delete_outline,color:Colors.red))))),
      if(ts.any((t)=>!t.done))TextButton.icon(onPressed:(){final to=dateKey(day.add(const Duration(days:1)));widget.store.moveUnfinished(key,to);},icon:const Icon(Icons.forward),label:const Text('نقل غير المنجز لليوم التالي'))
    ]));
  }
}
Future<void> addTaskDialog(BuildContext c,WisamStore s,String day)async{final x=TextEditingController();String p='low';final ok=await showDialog<bool>(context:c,builder:(c)=>StatefulBuilder(builder:(c,set)=>AlertDialog(title:const Text('مهمة جديدة'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:x,autofocus:true,decoration:const InputDecoration(hintText:'ماذا ستفعل؟')),DropdownButtonFormField<String>(value:p,items:const [DropdownMenuItem(value:'low',child:Text('أولوية منخفضة')),DropdownMenuItem(value:'high',child:Text('أولوية عالية'))],onChanged:(v)=>set(()=>p=v??'low'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,x.text.trim().isNotEmpty),child:const Text('إضافة'))])));if(ok==true)s.addTask(day,x.text.trim(),p);}

class ListsPage extends StatelessWidget{final WisamStore store;const ListsPage({super.key,required this.store});@override Widget build(BuildContext context)=>AppScroll(child:Column(children:[Header(title:'القوائم والكميات',subtitle:'قوائم المشتريات والمخزون',actions:[IconButton(onPressed:()=>addListDialog(context,store),icon:const Icon(Icons.add))]),if(store.lists.isEmpty)const EmptyState(text:'لا توجد قوائم'),...store.lists.map((l)=>ListCard(list:l,store:store))]));}
class ListCard extends StatelessWidget {
  final QuantityList list;
  final WisamStore store;

  const ListCard({super.key, required this.list, required this.store});

  @override
  Widget build(BuildContext context) {
    final done = list.items.where((i) => i.done).length;
    return Card(
      child: ExpansionTile(
        title: Text(list.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${arDigits(done)}/${arDigits(list.items.length)} مكتمل'),
        leading: CircleAvatar(
          backgroundColor: parseColor(list.color),
          child: const Icon(Icons.shopping_basket, color: Colors.white),
        ),
        trailing: IconButton(
          onPressed: () => store.deleteList(list.id),
          icon: const Icon(Icons.delete_outline),
        ),
        children: [
          ...list.items.map(
            (i) => ListTile(
              leading: Checkbox(
                value: i.done,
                onChanged: (v) => store.updateItem(list, i, done: v ?? false),
              ),
              title: Text(i.name),
              subtitle: Text('${arDigits(i.qty)} ${i.unit}${i.have > 0 ? '، تم توفير ${arDigits(i.have)}' : ''}'),
              trailing: IconButton(
                onPressed: () => store.deleteItem(list, i.id),
                icon: const Icon(Icons.delete_outline, size: 19),
              ),
            ),
          ),
          TextButton.icon(
            onPressed: () => addItemDialog(context, store, list),
            icon: const Icon(Icons.add),
            label: const Text('إضافة عنصر'),
          ),
        ],
      ),
    );
  }
}

Future<void> addListDialog(BuildContext c,WisamStore s)async{final x=TextEditingController();final ok=await showDialog<bool>(context:c,builder:(c)=>AlertDialog(title:const Text('قائمة جديدة'),content:TextField(controller:x,autofocus:true,decoration:const InputDecoration(hintText:'اسم القائمة')),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,x.text.trim().isNotEmpty),child:const Text('إنشاء'))]));if(ok==true)s.addList(x.text.trim(), '#C9A227');}
Future<void> addItemDialog(BuildContext c,WisamStore s,QuantityList l)async{final n=TextEditingController();final q=TextEditingController(text:'1');final ok=await showDialog<bool>(context:c,builder:(c)=>AlertDialog(title:const Text('عنصر جديد'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(hintText:'اسم العنصر')),TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الكمية'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,n.text.trim().isNotEmpty),child:const Text('إضافة'))]));if(ok==true)s.addItem(l,n.text.trim(),(double.tryParse(q.text) ?? 1),'قطعة');}

class BooksPage extends StatelessWidget{final WisamStore store;const BooksPage({super.key,required this.store});@override Widget build(BuildContext context)=>AppScroll(child:Column(children:[Header(title:'المكتبة',subtitle:'اكتب كتبك وفصولك',actions:[IconButton(onPressed:(){store.addBook();},icon:const Icon(Icons.add))]),if(store.books.isEmpty)const EmptyState(text:'لا توجد كتب'),...store.books.map((b)=>Card(child:ListTile(leading:const Icon(Icons.menu_book,color:gold),title:Text(b.title),subtitle:Text('بقلم: ${b.author.isEmpty?'غير محدد':b.author}'),onTap:()=>editBook(context,store,b),trailing:IconButton(onPressed:()=>store.deleteBook(b.id),icon:const Icon(Icons.delete_outline)))))]));}

Future<void> editBook(BuildContext c,WisamStore s,BookModel b)async{await Navigator.push(c,MaterialPageRoute(builder:(_)=>BookEditor(store:s,book:b)));}

class BookEditor extends StatefulWidget{final WisamStore store;final BookModel book;const BookEditor({super.key,required this.store,required this.book});@override State<BookEditor> createState()=>_BookEditorState();}
class _BookEditorState extends State<BookEditor>{
  late TextEditingController title,author,conclusion;
  @override void initState(){super.initState();title=TextEditingController(text:widget.book.title);author=TextEditingController(text:widget.book.author);conclusion=TextEditingController(text:widget.book.conclusion);}
  @override void dispose(){title.dispose();author.dispose();conclusion.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('تحرير الكتاب'),actions:[IconButton(onPressed:(){widget.store.updateBook(widget.book);Navigator.pop(context);},icon:const Icon(Icons.check))]),body:AppScroll(child:Column(children:[TextField(controller:title,decoration:const InputDecoration(labelText:'العنوان'),onChanged:(v)=>widget.book.title=v),TextField(controller:author,decoration:const InputDecoration(labelText:'المؤلف'),onChanged:(v)=>widget.book.author=v),const SizedBox(height:12),...widget.book.chapters.asMap().entries.map((e)=>ChapterEditor(chapter:e.value,index:e.key,onDelete:(){setState(()=>widget.book.chapters.removeAt(e.key));},onChanged:()=>widget.store.updateBook(widget.book))),TextButton.icon(onPressed:(){setState(()=>widget.book.chapters.add(Chapter(id:uid(),title:'فصل جديد')));},icon:const Icon(Icons.add),label:const Text('إضافة فصل')),TextField(controller:conclusion,minLines:5,maxLines:12,decoration:const InputDecoration(labelText:'الخاتمة'),onChanged:(v)=>widget.book.conclusion=v)])));}

class ChapterEditor extends StatelessWidget{final Chapter chapter;final int index;final VoidCallback onDelete,onChanged;const ChapterEditor({super.key,required this.chapter,required this.index,required this.onDelete,required this.onChanged});@override Widget build(BuildContext c){final t=TextEditingController(text:chapter.title),x=TextEditingController(text:chapter.content);return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[Row(children:[Expanded(child:TextField(controller:t,decoration:InputDecoration(labelText:'الفصل ${arDigits(index+1)}'),onChanged:(v){chapter.title=v;onChanged();})),IconButton(onPressed:onDelete,icon:const Icon(Icons.delete_outline,color:Colors.red))]),TextField(controller:x,minLines:5,maxLines:14,decoration:const InputDecoration(hintText:'محتوى الفصل'),onChanged:(v){chapter.content=v;onChanged();})])));}}

class DrawPage extends StatefulWidget {
  final WisamStore store;
  const DrawPage({super.key, required this.store});

  @override
  State<DrawPage> createState() => _DrawPageState();
}

class _DrawPageState extends State<DrawPage> {
  final points = <Offset>[];
  final canvasKey = GlobalKey();
  Color color = ink;
  double width = 4;

  @override
  Widget build(BuildContext c) {
    return Column(
      children: [
        Header(
          title: 'المرسم',
          subtitle: 'ارسم واحفظ الرسمة كملاحظة',
          actions: [
            IconButton(
              onPressed: () => setState(() => points.clear()),
              icon: const Icon(Icons.delete_sweep),
            ),
          ],
        ),
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: paper,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: GestureDetector(
              onPanStart: (d) => setState(() => points.add(d.localPosition)),
              onPanUpdate: (d) => setState(() => points.add(d.localPosition)),
              onPanEnd: (_) => setState(() => points.add(Offset.infinite)),
              child: RepaintBoundary(
                key: canvasKey,
                child: CustomPaint(
                  painter: DrawPainter(points, color, width),
                  size: Size.infinite,
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              const Text('حجم الفرشاة'),
              Expanded(
                child: Slider(
                  value: width,
                  min: 1,
                  max: 20,
                  onChanged: (v) => setState(() => width = v),
                ),
              ),
              IconButton(
                onPressed: () => setState(() => color = ink),
                icon: const Icon(Icons.circle, color: ink),
              ),
              IconButton(
                onPressed: () => setState(() => color = emerald),
                icon: const Icon(Icons.circle, color: emerald),
              ),
              FilledButton.icon(
                onPressed: () => saveDrawing(c),
                icon: const Icon(Icons.save),
                label: const Text('حفظ كملاحظة'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> saveDrawing(BuildContext c) async {
    if (points.isEmpty) {
      ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('ارسم شيئًا أولًا')));
      return;
    }
    final boundary = canvasKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) return;
    final image = await boundary.toImage(pixelRatio: 2);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    widget.store.notes.insert(
      0,
      NoteModel(
        id: uid(),
        title: 'رسمة',
        content: '',
        drawing: base64Encode(data.buffer.asUint8List()),
        createdAt: now,
        updatedAt: now,
      ),
    );
    widget.store.changed();
    ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('حُفظت الرسمة كملاحظة')));
  }
}

class DrawPainter extends CustomPainter{final List<Offset> p;final Color c;final double w;DrawPainter(this.p,this.c,this.w);@override void paint(Canvas canvas,Size size){final paint=Paint()..color=c..strokeWidth=w..strokeCap=StrokeCap.round;for(int i=1;i<p.length;i++){if(p[i-1].isFinite&&p[i].isFinite)canvas.drawLine(p[i-1],p[i],paint);}}@override bool shouldRepaint(covariant DrawPainter old)=>true;}

class AppScroll extends StatelessWidget{final Widget child;const AppScroll({super.key,required this.child});@override Widget build(BuildContext c)=>SingleChildScrollView(padding:const EdgeInsets.fromLTRB(18,18,18,30),child:child);}
class Header extends StatelessWidget {
  final String title, subtitle;
  final List<Widget> actions;

  const Header({super.key, required this.title, required this.subtitle, this.actions = const []});

  @override
  Widget build(BuildContext c) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                Text(subtitle, style: const TextStyle(color: Colors.grey)),
              ],
            ),
          ),
          ...actions,
        ],
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final VoidCallback onTap;

  const StatCard({super.key, required this.label, required this.value, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext c) {
    return SizedBox(
      width: 190,
      child: Card(
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                CircleAvatar(backgroundColor: goldSoft, child: Icon(icon, color: ink)),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                    Text(label, style: const TextStyle(color: Colors.grey)),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const SectionCard({super.key, required this.title, required this.icon, required this.child});

  @override
  Widget build(BuildContext c) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Icon(icon, color: emerald), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))]),
            const SizedBox(height: 8),
            child,
          ],
        ),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final String text;
  const EmptyState({super.key, required this.text});

  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.all(35),
    child: Center(child: Text(text, style: const TextStyle(color: Colors.grey))),
  );
}

Color parseColor(String s){try{return Color(int.parse(s.replaceFirst('#','0xff')));}catch(_){return gold;}}
Color noteColor(String k)=>{'paper':const Color(0xFFFFFDF6),'mint':const Color(0xFFEDF6EF),'blush':const Color(0xFFFBEDEF),'sky':const Color(0xFFEBF2F8),'lavender':const Color(0xFFF2EEF9),'night':const Color(0xFF262119)}[k]??paper;

Future<void> backup(BuildContext c)async{final store=getStore(c);final dir=await getTemporaryDirectory();final f=File('${dir.path}/wisam_backup.json');await f.writeAsString(store.exportJson());await SharePlus.instance.share(ShareParams(files:[XFile(f.path)],text:'نسخة احتياطية من وِسام'));}
Future<void> importBackup(BuildContext c)async{final store=getStore(c);final r=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json']);if(r?.files.single.path==null)return;final ok=await store.importJson(await File(r!.files.single.path!).readAsString());ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(ok?'تم استيراد البيانات':'ملف غير صالح')));}
WisamStore getStore(BuildContext c)=>c.findAncestorWidgetOfExactType<InheritedWisam>()!.store;

class InheritedWisam extends InheritedWidget{final WisamStore store;const InheritedWisam({super.key,required this.store,required super.child});@override bool updateShouldNotify(covariant InheritedWisam old)=>old.store!=store;}

Future<void> settingsDialog(BuildContext c,WisamStore s)async{await showDialog(context:c,builder:(c)=>AlertDialog(title:const Text('الإعدادات'),content:Column(mainAxisSize:MainAxisSize.min,children:[ListTile(title:const Text('الملاحظات'),trailing:Text(arDigits(s.noteCount))),ListTile(title:const Text('الكتب'),trailing:Text(arDigits(s.books.length))),ListTile(title:const Text('إجمالي الكلمات'),trailing:Text(arDigits(s.wordTotal)))]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إغلاق')),TextButton(onPressed:(){s.reset();Navigator.pop(c);},child:const Text('إعادة تعيين'))]));}
