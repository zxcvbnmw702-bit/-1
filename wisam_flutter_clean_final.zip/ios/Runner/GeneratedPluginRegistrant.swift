import Flutter
import UIKit
func GeneratedPluginRegistrant_register(with registry: FlutterPluginRegistry) {}
