# وِسام Flutter

مشروع Flutter مستقل، مجهز للرفع إلى FlutLab.

## التشغيل في FlutLab

1. ارفع ملف ZIP إلى FlutLab كمشروع Flutter.
2. انتظر تنزيل الحزم.
3. شغّل المشروع من Run.
4. استخدم Build APK من أدوات Android إذا ظهر الخيار.

## ملاحظات

- نقطة الدخول: `lib/main.dart`
- ملف الحزم: `pubspec.yaml`
- تم تحديث واجهة `share_plus` إلى `SharePlus.instance.share` لتجنب مشاكل API القديمة.
- تم تثبيت إصدارات الحزم لتقليل اختلافات البناء بين البيئات.
