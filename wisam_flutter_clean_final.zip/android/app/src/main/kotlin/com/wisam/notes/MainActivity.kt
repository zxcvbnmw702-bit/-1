package com.wisam.notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
