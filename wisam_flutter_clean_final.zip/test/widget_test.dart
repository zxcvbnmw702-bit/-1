import 'package:flutter_test/flutter_test.dart';
import 'package:wisam_notes/main.dart';

void main() {
  testWidgets('Wisam app starts', (tester) async {
    final store = WisamStore();
    await tester.pumpWidget(WisamApp(store: store));
    await tester.pump();
    expect(find.byType(WisamApp), findsOneWidget);
  });
}
